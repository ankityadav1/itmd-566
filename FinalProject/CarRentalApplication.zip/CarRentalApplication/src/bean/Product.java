package bean;


import java.util.*;

public class Product
{

    String retailer;
    String name;
    String id;
    String image;
    String condition;
    int price;
    String quantity;
    String manufactRebate;
    String onSale;
    ProductType productType;
    //List<String> accessories;


    
    public Product(String retailer, String name, String id, String image, String condition, int price,  String quantity,
    String manufactRebate,    String onSale,ProductType producttype)
    {
    	this.retailer = retailer;
    	this.price = price;
    	this.name = name;
    	this.id = id;
    	this.image = image;
    	this.manufactRebate=manufactRebate;
    	this.condition=condition;
    	this.onSale=onSale;
    	this.quantity=quantity;
    	this.productType=producttype;
    	
    }

    
    
    public Product()
    {
       // accessories=new ArrayList<String>();
    }

	public String getRetailer()
	{
		return retailer;
	}

	public void setRetailer(String retailer) 
	{
		this.retailer = retailer;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public String getId() 
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getImage()
	{
		return image;
	}

	public void setImage(String image)
	{
		this.image = image;
	}

	public String getCondition() 
	{
		return condition;
	}

	public void setCondition(String condition)
	{
		this.condition = condition;
	}

	public int getPrice() 
	{
		return price;
	}

	public void setPrice(int price)
	{
		this.price = price;
	}

	



	public ProductType getProductType()
	{
		return productType;
	}

	public void setProductType(ProductType productType)
	{
		this.productType = productType;
	}
	public String getQuantity() 
	{
		return quantity;
	}

	public void setQuantity(String quantity) 
	{
		this.quantity = quantity;
	}
	public String getManfactRebate() 
	{
		return manufactRebate;
	}

	public void setManufactRebate(String manufactRebate) 
	{
		this.manufactRebate = manufactRebate;
	}
	public String getOnSale() 
	{
		return onSale;
	}

	public void setOnSale(String onSale) 
	{
		this.onSale = onSale;
	}


}