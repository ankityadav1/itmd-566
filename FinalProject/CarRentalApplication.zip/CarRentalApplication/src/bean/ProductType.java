package bean;


public enum ProductType 
{
    MOBILE,
    LAPTOP,
    HEADPHONE,
    EXTERNALSTORAGE,
    SMARTWATCHES,
    SPEAKER,
}
